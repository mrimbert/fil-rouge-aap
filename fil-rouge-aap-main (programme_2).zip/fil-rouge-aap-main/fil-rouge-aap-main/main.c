#include <stdio.h>
#include "./utils/super_morpion.h"

int main() {
    // Créer une nouvelle instance de super-morpion
    super_morpion sm = newSuperMorpion();
    
    // Remplir quelques grilles avec des valeurs pour simuler un jeu en cours
    sm.g[0][0] = ROND;
    sm.g[0][1] = CROIX;
    // ... continuez à remplir d'autres cases au besoin

    // Test 1: Vérifier si le jeu n'est pas terminé avec un plateau partiellement rempli
    if (isOverSuperMorpion(&sm)) {
        printf("Le jeu est terminé (ne devrait pas l'être dans ce cas).\n");
    } else {
        printf("Le jeu n'est pas terminé (comportement attendu).\n");
    }

    // Remplir toutes les grilles pour simuler un plateau plein
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            sm.g[i][j] = (j % 2 == 0) ? ROND : CROIX;  // Remplir alternativement avec ROND et CROIX
        }
    }

    // Test 2: Vérifier si le jeu est terminé avec un plateau plein
    if (isOverSuperMorpion(&sm)) {
        printf("Le jeu est terminé (comportement attendu).\n");
    } else {
        printf("Le jeu n'est pas terminé (ne devrait pas l'être dans ce cas).\n");
    }

    return 0;
}

